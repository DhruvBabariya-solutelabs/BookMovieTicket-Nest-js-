export enum role {
  USER = 'user',
  ADMIN = 'admin',
  SUPER_ADMIN = 'super-admin',
}

export enum seatType {
  gold = 'gold',
  silver = 'silver',
  platinum = 'platinum',
}
