import {
  Injectable,
  NotAcceptableException,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateShowDto } from 'src/dto/create-show.dto';
import { UpdateShowDto } from 'src/dto/update-show.dto';
import { Shows } from 'src/entities/shows.entites';
import { User } from 'src/entities/user.entity';
import { MovieService } from 'src/movie/movie.service';
import { Repository } from 'typeorm';

@Injectable()
export class ShowService {
  constructor(
    @InjectRepository(Shows) private readonly showsRepo: Repository<Shows>,
    private readonly movieService: MovieService,
  ) {}

  async create(createShowDto: CreateShowDto, user: User): Promise<Shows> {
    const movie = await this.movieService.findOne(createShowDto.movieId);
    if (!movie) {
      throw new NotFoundException('Movie does not Found');
    }
    const datetime = new Date(createShowDto.showTime);
    if (movie.releaseDate > datetime) {
      throw new NotAcceptableException('Please Fill valid ShowTime');
    }
    const totalseat =
      createShowDto.goldSeat +
      createShowDto.silverSeat +
      createShowDto.platinumSeat;
    const show = this.showsRepo.create(createShowDto);
    show.totalSeats = totalseat;
    show.availableSeats = totalseat;
    show.time = datetime;
    show.user = user;
    show.movie = movie;
    return this.showsRepo.save(show);
  }

  async findAll() {
    try {
      const shows = await this.showsRepo.find();
      if (shows.length === 0) {
        throw new NotFoundException('Shows are Not Found in db');
      }
      return shows;
    } catch (err) {
      throw new Error(err);
    }
  }

  async findOne(id: number) {
    try {
      const show = await this.showsRepo.findOne({ where: { id } });
      if (!show) {
        throw new NotFoundException('User is Not Found');
      }
      return show;
    } catch (err) {
      throw new Error(err);
    }
  }

  async update(id: number, updateShowDto: UpdateShowDto) {
    try {
      const show = await this.findOne(id);
      if (updateShowDto.showTime) {
        const date = new Date(updateShowDto.showTime);
        updateShowDto.showTime = date;
      }
      Object.assign(show, updateShowDto);
      return this.showsRepo.save(show);
    } catch (err) {
      throw new Error(err);
    }
  }

  async remove(id: number) {
    const show = await this.findOne(id);
    return this.showsRepo.remove(show);
  }
}
