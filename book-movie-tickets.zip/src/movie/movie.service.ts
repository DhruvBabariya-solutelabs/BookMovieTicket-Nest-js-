import {
  Injectable,
  NotFoundException,
  UnprocessableEntityException,
  InternalServerErrorException,
} from '@nestjs/common';
import { CreateMovieDto } from '../dto/create-movie.dto';
import { User } from 'src/entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Movie } from 'src/entities/movie.entity';
import { Repository } from 'typeorm';
import { BookTicketDto } from 'src/dto/book-ticket.dto';
import { Shows } from 'src/entities/shows.entites';
import { seatType } from 'src/util/constant.util';
import { MovieTicket } from 'src/entities/movie-ticket.entity';

@Injectable()
export class MovieService {
  constructor(
    @InjectRepository(Movie) private readonly movieRepo: Repository<Movie>,
    @InjectRepository(MovieTicket)
    private readonly movieTicketRepo: Repository<MovieTicket>,
  ) {}

  async create(createMovieDto: CreateMovieDto, user: User) {
    try {
      const date = createMovieDto.releaseDate;
      const releaseDate = new Date(date);
      createMovieDto.releaseDate = releaseDate;
      const movie = this.movieRepo.create(createMovieDto);
      movie.createdby = user;
      return this.movieRepo.save(movie);
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async findAll(): Promise<Movie[]> {
    try {
      const movies = await this.movieRepo.find({
        relations: {
          shows: true,
          createdby: true,
        },
      });
      if (movies.length === 0) {
        throw new NotFoundException('Movie is Not Found');
      }
      return movies;
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async findOne(id: number): Promise<Movie> {
    try {
      const movie = await this.movieRepo.findOne({
        where: { id },
        relations: {
          shows: true,
          createdby: true,
        },
      });
      if (!movie) {
        throw new NotFoundException('Movie Does not found');
      }
      return movie;
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async update(id: number, attrs: Partial<Movie>): Promise<Movie> {
    try {
      const movie = await this.findOne(id);
      Object.assign(movie, attrs);
      return this.movieRepo.save(movie);
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async remove(id: number): Promise<{ message: string; movie: Movie }> {
    const movie = await this.findOne(id);
    const removedMovie = await this.movieRepo.remove(movie);
    if (!removedMovie) {
      throw new NotFoundException('Movie does not Found');
    }
    return {
      message: 'Movie Deleted Successfully',
      movie: removedMovie,
    };
  }

  async bookMovieTicket(
    movieId: number,
    bookTicketDto: BookTicketDto,
    user: User,
  ): Promise<MovieTicket> {
    try {
      const showTime = new Date(bookTicketDto.showTime);

      const movie = await this.findOne(movieId);
      const releaseDate = movie.releaseDate;
      const currentDate = new Date();
      if (currentDate.getTime() < releaseDate.getTime()) {
        throw new UnprocessableEntityException(
          'can not booked ticket of upcomming movies',
        );
      }
      const currentTime = Date.now();
      if (showTime.getTime() < currentTime) {
        throw new UnprocessableEntityException('show time is not available');
      }
      const shows = movie.shows;
      let show: Shows;
      let index: number;
      let price: number;
      for (let i = 0; i < shows.length; i++) {
        if (showTime.toString() == shows[i].time.toString()) {
          show = shows[i];
          index = i;
        }
      }
      if (!show) {
        throw new UnprocessableEntityException('show is not available');
      } else {
        if (show.availableSeats === 0) {
          throw new UnprocessableEntityException('seat is not available');
        }
        if (bookTicketDto.seat === seatType.gold) {
          if (show.goldSeat === 0) {
            throw new UnprocessableEntityException(
              'Gold seat is not available',
            );
          }
          movie.shows[index].goldSeat -= 1;
          price = movie.shows[index].goldPrice;
        } else if (bookTicketDto.seat === seatType.silver) {
          if (show.silverSeat === 0) {
            throw new UnprocessableEntityException(
              'Silver seat is not available',
            );
          }
          movie.shows[index].silverSeat -= 1;
          price = movie.shows[index].silverPrice;
        } else {
          if (show.platinumSeat === 0) {
            throw new UnprocessableEntityException(
              'Platinum seat is not available',
            );
          }
          movie.shows[index].platinumSeat -= 1;
          price = movie.shows[index].platinumPrice;
        }

        movie.shows[index].availableSeats -= 1;
        const updatedMovie = await this.movieRepo.save(movie);
        if (updatedMovie) {
          const movieTicket = this.movieTicketRepo.create(bookTicketDto);
          movieTicket.price = price;
          movieTicket.movie = movie;
          movieTicket.user = user;
          return this.movieTicketRepo.save(movieTicket);
        }
      }
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async cancelMovieTicket(
    id: number,
    user: User,
  ): Promise<{ message: string }> {
    try {
      const ticket = await this.movieTicketRepo.findOne({
        where: { id },
        relations: { movie: true, user: true },
      });
      const movieId = ticket.movie.id;
      const seat = ticket.seat;
      const showTime = ticket.showTime;
      let index: number;
      const movie = await this.findOne(movieId);
      const shows = movie.shows;
      for (let i = 0; i < shows.length; i++) {
        if (showTime.toString() == shows[i].time.toString()) {
          index = i;
        }
      }
      movie.shows[index].availableSeats += 1;
      if (seat == seatType.gold) {
        movie.shows[index].goldSeat += 1;
      } else if (seat == seatType.silver) {
        movie.shows[index].silverSeat += 1;
      } else {
        movie.shows[index].platinumSeat += 1;
      }

      const movies = await this.movieRepo.save(movie);
      if (!movies) {
        throw new NotFoundException('shows does not updated try aganin');
      }
      const tickets = await this.movieTicketRepo.remove(ticket);
      if (!tickets) {
        throw new NotFoundException('ticket does not cancel');
      }
      return {
        message: 'ticket cancel successfully',
      };
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async findUpcommingMovies(): Promise<Movie[]> {
    try {
      const currentTime = new Date();
      console.log(currentTime);
      const movies = await this.movieRepo
        .createQueryBuilder('movie')
        .leftJoinAndSelect('movie.shows', 'shows')
        .where('movie.releaseDate > :currentTime', { currentTime })
        .orderBy('movie.releaseDate', 'ASC')
        .getMany();

      if (!movies) {
        throw new NotFoundException('Not Upcomming movies are there');
      }
      return movies;
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async currentMovieShortByShows(): Promise<Movie[]> {
    try {
      const movies = await this.movieRepo
        .createQueryBuilder('movie')
        .leftJoinAndSelect('movie.shows', 'shows')
        .where('movie.releaseDate < :currentTime', { currentTime: new Date() })
        .andWhere('shows.time >= :currentTime', { currentTime: new Date() })
        .orderBy('shows.time', 'ASC')
        .getMany();
      if (!movies) {
        throw new NotFoundException('Not Upcomming movies are there');
      }
      return movies;
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }
}
