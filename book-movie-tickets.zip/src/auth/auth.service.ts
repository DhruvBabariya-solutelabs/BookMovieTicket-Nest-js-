import {
  Injectable,
  UnauthorizedException,
  HttpStatus,
  Get,
  InternalServerErrorException,
} from '@nestjs/common';
import { CreateUserDto } from 'src/dto/create-user.dto';
import { UserService } from 'src/user/user.service';
import { LoginDto } from '../dto/login.dto';
import { compare } from 'bcrypt';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { role } from 'src/util/constant.util';
import { User } from 'src/entities/user.entity';

@Injectable()
export class AuthService {
  constructor(
    private readonly userService: UserService,
    private readonly config: ConfigService,
    private readonly jwtService: JwtService,
  ) {}

  async signup(createUserDto: CreateUserDto, user?: User): Promise<User> {
    try {
      let userRole = role.USER;
      let users = await this.userService.findAll();
      if (users.length == 0) {
        userRole = role.SUPER_ADMIN;
      } else {
        const superAdmin = await this.userService.findByRole(role.SUPER_ADMIN);
        if (!superAdmin) {
          userRole = role.SUPER_ADMIN;
        }
      }
      if (user) {
        if (user.role === role.SUPER_ADMIN) {
          userRole = role.ADMIN;
        }
      }
      return this.userService.create(createUserDto, userRole);
    } catch (err) {
      throw new Error(err);
    }
  }

  async login(loginDto: LoginDto): Promise<{ access_token: string }> {
    try {
      const user = await this.userService.findByEmail(loginDto.email);
      if (!user) {
        throw new UnauthorizedException('email does not exist');
      }
      if (user.status === 0) {
        throw new UnauthorizedException('Deactivated Account by admin');
      }
      const isEqual = await compare(loginDto.password, user.password.trim());
      if (!isEqual) {
        throw new UnauthorizedException('Wrong Password');
      }
      return this.signToken(user.id, user.email);
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }

  async signToken(
    userId: number,
    email: string,
  ): Promise<{ access_token: string }> {
    const payload = {
      sub: userId,
      email,
    };

    const secret = this.config.get('JWT_SECRET_KEY');
    try {
      const token = await this.jwtService.signAsync(payload, {
        expiresIn: '1h',
        secret: secret,
      });
      return {
        access_token: token,
      };
    } catch (err) {
      throw new InternalServerErrorException('Internal server Exception');
    }
  }
}
