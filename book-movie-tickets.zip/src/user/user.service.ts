import { Injectable, HttpStatus, NotFoundException } from '@nestjs/common';
import { CreateUserDto } from '../dto/create-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from '../entities/user.entity';
import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { hash } from 'bcrypt';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    private readonly configService: ConfigService,
  ) {}

  async create(createUserDto: CreateUserDto, userRole: string) {
    try {
      const user = this.userRepository.create(createUserDto);
      const hashPassword = await hash(user.password, 10);
      user.password = hashPassword;
      user.role = userRole;
      return this.userRepository.save(user);
    } catch (error) {
      error.statusCode = 500;
      throw new error();
    }
  }

  async findAll() {
    const users = await this.userRepository.find();
    if (!users) {
      throw new NotFoundException('Not Found any User in Db');
    }
    return users;
  }

  async findOne(id: number) {
    const user = await this.userRepository.findOne({
      where: { id },
      relations: {
        movieTicket: true,
      },
    });
    if (!user) {
      throw new NotFoundException('Not Found any User in Db');
    }
    return user;
  }

  async findByEmail(email: string) {
    return this.userRepository.findOne({ where: { email } });
  }

  async findByRole(role: string) {
    return this.userRepository.findOne({ where: { role } });
  }

  async update(id: number, attrs: Partial<User>) {
    const user = await this.findOne(id);
    if (!user) {
      throw new NotFoundException('User Not Found');
    }
    Object.assign(user, attrs);
    return this.userRepository.save(user);
  }

  async remove(id: number) {
    const user = await this.findOne(id);
    if (!user) {
      throw new NotFoundException('User Not Found');
    }
    return this.userRepository.remove(user);
  }
}
